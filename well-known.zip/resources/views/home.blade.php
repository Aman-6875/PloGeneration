@extends('layout')

@section('content')
    <div class="page-content">
        <div class="container-fluid">
            @php
            $developer=0;
            $designer=0;
            $ceo=0;
            $cto=0;
            $entrepreneur=0;
            $startup=0;
            $undefined=0;
            $marketer=0;
            $seo=0;
            $data_scientist=0;
            $Linux=0;
            $Mac=0;
            $Windows=0;
            $Facebook=0;
            $Google=0;
            $LinkedIn=0;
            $Twitter=0;
            $Instagram=0;
            $Github=0;
        @endphp

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="mb-sm-0 font-size-18">Dashboard</h4>

                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="/">Dashboards</a></li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-xl-4">
                    <div class="card overflow-hidden">
                        <div class="bg-primary bg-soft">
                            <div class="row">
                                <div class="col-7">
                                    <div class="text-primary p-3">
                                        <h5 class="text-primary">Welcome Back !</h5>
                                        <h5 class="font-size-15 text-truncate">{{ Auth::user()->name }}</h5>

                                    </div>
                                </div>
                                <div class="col-5 align-self-end">
                                    <img src="/assets/images/profile-img.png" alt="" class="img-fluid">
                                </div>
                            </div>
                        </div>
                        <div class="card-body pt-0">
                            <div class="row">

                            </div>
                        </div>
                    </div>

                </div>
                <div class="col-xl-8">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="card mini-stats-wid">
                                <div class="card-body">
                                    <div class="media">
                                        <div class="media-body">
                                            <p class="text-muted fw-medium">Total Customers</p>
                                            <h4 class="mb-0">{{ $customer }}</h4>
                                        </div>

                                        <div class="mini-stat-icon avatar-sm rounded-circle bg-primary align-self-center">
                                            <span class="avatar-title">
                                                <i class="bx bx-copy-alt font-size-24"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        @if (Auth::user()->user_type == 1)
                            <div class="col-md-4">
                                <div class="card mini-stats-wid">
                                    <div class="card-body">
                                        <div class="media">
                                            <div class="media-body">
                                                <p class="text-muted fw-medium">Active Users</p>
                                                <h4 class="mb-0">{{ $active }}</h4>
                                            </div>

                                            <div
                                                class="avatar-sm rounded-circle bg-primary align-self-center mini-stat-icon">
                                                <span class="avatar-title rounded-circle bg-primary">
                                                    <i class="bx bx-archive-in font-size-24"></i>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card mini-stats-wid">
                                    <div class="card-body">
                                        <div class="media">
                                            <div class="media-body">
                                                <p class="text-muted fw-medium">Pending Users</p>
                                                <h4 class="mb-0">{{ $pending }}</h4>
                                            </div>

                                            <div
                                                class="avatar-sm rounded-circle bg-primary align-self-center mini-stat-icon">
                                                <span class="avatar-title rounded-circle bg-primary">
                                                    <i class="bx bx-archive-in font-size-24"></i>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            @foreach ($Allcustomer as $item)
                                @if ($item->profession == 'Developer')
                                    @php
                                        $developer++;
                                    @endphp
                                @elseif($item->profession == 'Designer')
                                    @php
                                        $designer++
                                    @endphp
                                @elseif($item->profession == 'Ceo')
                                    @php
                                        $ceo++
                                    @endphp
                                @elseif($item->profession == 'Cto')
                                    @php
                                        $cto++
                                    @endphp
                                @elseif($item->profession == 'Entrepreneur')
                                    @php
                                        $entrepreneur++
                                    @endphp
                                @elseif($item->profession == 'Startup owner')
                                    @php
                                        $startup++
                                    @endphp
                                @elseif($item->profession == 'Undefined')
                                    @php
                                        $undefined++
                                    @endphp
                                @elseif($item->profession == 'Marketer')
                                    @php
                                        $marketer++
                                    @endphp
                                @elseif($item->profession == 'Seo specilist')
                                    @php
                                        $seo++
                                    @endphp
                                @elseif($item->profession == 'Data scientist')
                                    @php
                                        $data_scientist++
                                    @endphp
                                @endif
                                @if ($item->device == 'Linux')
                                    @php
                                        $Linux++;
                                    @endphp
                                @elseif($item->device == 'Mac')
                                    @php
                                        $Mac++
                                    @endphp
                                @elseif($item->device == 'Windows')
                                    @php
                                        $Windows++
                                    @endphp
                                @endif
                                @if ($item->facebook_link != null)
                                    @php
                                        $Facebook++;
                                    @endphp
                                    @endif
                                @if($item->google_link != null)
                                    @php
                                        $Google++
                                    @endphp
                                    @endif
                                @if($item->linked_in_link != null)
                                    @php
                                        $LinkedIn++
                                    @endphp
                                    @endif
                                @if($item->twitter_link != null)
                                    @php
                                        $Twitter++
                                    @endphp
                                    @endif

                                @if($item->instagram_link != null)
                                    @php
                                        $Instagram++
                                    @endphp
                                    @endif
                                @if($item->github_link != null)
                                    @php
                                        $Github++
                                    @endphp
                                @endif

                            @endforeach
                            <div class="col-md-6">
                                <div class="card mini-stats-wid">
                                    <div class="card-body">
                                        <div class="media">
                                            <div class="media-body">
                                                <p class="text-muted fw-medium">Customer Data Based on Profession</p>

                                                <h4 class="mb-0">Developer:{{$developer}}</h4>
                                                <h4 class="mb-0">Designer:{{$designer}}</h4>
                                                <h4 class="mb-0">Ceo:{{$ceo}}</h4>
                                                <h4 class="mb-0">Cto:{{$cto}}</h4>
                                                <h4 class="mb-0">Entrepreneur:{{$entrepreneur}}</h4>
                                                <h4 class="mb-0">Startup owner:{{$startup}}</h4>
                                                <h4 class="mb-0">Undefined:{{$undefined}}</h4>
                                                <h4 class="mb-0">Marketer:{{$marketer}}</h4>
                                                <h4 class="mb-0">Seo specilist:{{$seo}}</h4>
                                                <h4 class="mb-0">Data scientist:{{$data_scientist}}</h4>

                                            </div>

                                            <div
                                                class="avatar-sm rounded-circle bg-primary align-self-center mini-stat-icon">
                                                <span class="avatar-title rounded-circle bg-primary">
                                                    <i class="bx bx-archive-in font-size-24"></i>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card mini-stats-wid">
                                    <div class="card-body">
                                        <div class="media">
                                            <div class="media-body">
                                                <p class="text-muted fw-medium">Customer Data Based on Device</p>

                                                <h4 class="mb-0">Linux:{{$Linux}}</h4>
                                                <h4 class="mb-0">Mac:{{$Mac}}</h4>
                                                <h4 class="mb-0">Windows:{{$Windows}}</h4>
                                            </div>

                                            <div
                                                class="avatar-sm rounded-circle bg-primary align-self-center mini-stat-icon">
                                                <span class="avatar-title rounded-circle bg-primary">
                                                    <i class="bx bx-archive-in font-size-24"></i>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="media">
                                            <div class="media-body">
                                                <p class="text-muted fw-medium">Customer Data Based on Social Link</p>
                                                <h4 class="mb-0">Facebook-User:{{$Facebook}}</h4>
                                                <h4 class="mb-0">Google-User:{{$Google}}</h4>
                                                <h4 class="mb-0">LinkedIn-User:{{$LinkedIn}}</h4>
                                                <h4 class="mb-0">Twitter-User:{{$Twitter}}</h4>
                                                <h4 class="mb-0">Instagram-User:{{$Instagram}}</h4>
                                                <h4 class="mb-0">Github-User:{{$Github}}</h4>
                                            </div>

                                            <div
                                                class="avatar-sm rounded-circle bg-primary align-self-center mini-stat-icon">
                                                <span class="avatar-title rounded-circle bg-primary">
                                                    <i class="bx bx-archive-in font-size-24"></i>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>





                    </div>
                    <!-- end row -->
                </div>
            </div>
            <!-- end row -->
            <br><br>
            <div class="row">
                <div class="col-md-6">
                    <div id="pie_chart" style="width:550px; height:450px;"></div>
                </div>
                <div class="col-md-6">
                    <div id="pie_chart_country" style="width:550px; height:450px;"></div>
                </div>
                <div class="col-md-6">
                    <div id="pie_chart_profession" style="width:550px; height:450px;"></div>
                </div>
                <div class="col-md-6">
                    <div id="pie_chart_device" style="width:550px; height:450px;"></div>
                </div>
                <div class="col-md-6">
                    <div id="pie_chart_social" style="width:550px; height:450px;"></div>
                </div>
                <div class="col-md-6">
                    <div id="pie_chart_price" style="width:550px; height:450px;"></div>
                </div>
                {{-- <div class="col-md-6">
                    <canvas id="myChart2"></canvas>
                </div> --}}
            </div>
            @endif
        </div>
        <!-- container-fluid -->
    </div>




    <script>
        var analytics = <?php echo $gender; ?>;
        var country = <?php echo $country; ?>;
        var profession = <?php echo $profession; ?>;
        var device = <?php echo $device; ?>;
        var price = <?php echo $price; ?>;
        var Facebook = <?php echo $Facebook; ?>;
        var Google = <?php echo $Google; ?>;
        var LinkedIn = <?php echo $LinkedIn; ?>;
        var Twitter = <?php echo $Twitter; ?>;
        var Instagram = <?php echo $Instagram; ?>;
        var Github = <?php echo $Github; ?>;



        google.charts.load('current', {'packages':['corechart']});

        google.charts.setOnLoadCallback(drawChart);
        google.charts.setOnLoadCallback(drawCountryChart);
        google.charts.setOnLoadCallback(drawProfessionChart);
        google.charts.setOnLoadCallback(drawDeviceChart);
        google.charts.setOnLoadCallback(drawSocialChart);
        google.charts.setOnLoadCallback(drawPriceChart);

        function drawChart()
        {
            var data = google.visualization.arrayToDataTable(analytics);
            var options = {
            title : 'Percentage of Male and Female Customer'
            };
            var chart = new google.visualization.PieChart(document.getElementById('pie_chart'));
            chart.draw(data, options);
        }
        function drawCountryChart()
        {
            var country_data = google.visualization.arrayToDataTable(country);
            var options = {
            title : 'Country Based Customer'
            };
            var chart = new google.visualization.PieChart(document.getElementById('pie_chart_country'));
            chart.draw(country_data, options);
        }
        function drawProfessionChart()
        {
            var profession_data = google.visualization.arrayToDataTable(profession);
            var options = {
            title : 'Profession Based Customer'
            };
            var chart = new google.visualization.PieChart(document.getElementById('pie_chart_profession'));
            chart.draw(profession_data, options);
        }
        function drawDeviceChart()
        {
            var device_data = google.visualization.arrayToDataTable(device);
            var options = {
            title : 'Device Based Customer'
            };
            var chart = new google.visualization.PieChart(document.getElementById('pie_chart_device'));
            chart.draw(device_data, options);
        }
        function drawPriceChart()
        {
            var price_data = google.visualization.arrayToDataTable(price);
            var options = {
            title : 'Price Based Customer'
            };
            var chart = new google.visualization.PieChart(document.getElementById('pie_chart_price'));
            chart.draw(price_data, options);
        }
        function drawSocialChart()
        {
            var social_data = google.visualization.arrayToDataTable([
            ['Task', 'Hours per Day'],
            ['Facebook',     Facebook],
            ['Google',     Google],
            ['LinkedIn',     LinkedIn],
            ['Twitter',     Twitter],
            ['Instagram',     Instagram],
            ['Github',     Github],

             ]);
            var options = {
            title : 'Social Based Customer'
            };
            var chart = new google.visualization.PieChart(document.getElementById('pie_chart_social'));
            chart.draw(social_data, options);
        }
    </script>
@endsection
