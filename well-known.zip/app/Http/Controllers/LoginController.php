<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class LoginController extends Controller
{

    public function index(){
        return view('login');
    }
    public function registerIndex(){
        return view('register');
    }

    public function login(Request $request){
        $user = User::where('email',$request->email)->first();
        if($user){
            if($user->is_admin==1){
                if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
                    return redirect()->intended('/');
                 }
                 else{
                    return back()->with('failed','Login Error, Use Valid Credentials!');
                 }
            }else{
                return back()->with('failed','You need an approval for Login!');
            }
        }else{
            return back()->with('failed','Register First For Login!!');
        }
    }
    public function register(Request $request){
        $validator = Validator::make($request->all(),[
            'email'=>'required|email',
            'password'=>'required|min:6',
            'name'=>'required'
         ]);
         if ($validator->fails()) {
            return redirect()->back()
                        ->withErrors($validator)
                        ->withInput();
        }else{
            $data = [
                'name'=>$request->name,
                'email'=>$request->email,
                'password'=>Hash::make($request->password),
                'user_type'=>0,
                'is_admin'=>1,
             ];
             $user = User::where('email',$request->email)->first();

          if($user){
            return back()->with('failed', "Email is already taken. ");
          }else{
            try {
                User::create($data);
                return back()->with('success', "Your Account has created Successfully. Please wait for Approval");
            } catch (\Exception $exception) {
                return back()->with('failed', $exception->getMessage());
            }
          }
        }
    }

    public function logout(){
        Auth::logout();
        return redirect('/login');
    }



}
