<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="container-fluid">

        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0 font-size-18"><?php echo e(\App\Courses::find($course_code)->course_code); ?></h4>

                     <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="/plo-generation">All PLO</a></li>
                        </ol>
                    </div>

                </div>
            </div>
        </div>
        <!-- end page title -->

        <div class="row">
            <div class="card">
                <div class="card-body">
                    <center>
                        <h4 class="card-title mb-4"><?php echo e(\App\Courses::find($course_code)->course_code); ?></h4>
                    </center>

                    <div class="row">
                        <div class="col-xl-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-2">
                                            <div class="table-responsive">
                                                <table class="table table-bordered border-primary mb-0">

                                                    <thead>
                                                        <tr>
                                                            <th>GPA</th>
                                                            <td>
                                                                <?php
                                                                 $gpa = ($total1+$total2+$total2+$total4+$total5+$total6+$total7+$total8+$total9+$total10);
                                                                ?>


                                                            <?php if($gpa>=90): ?>
                                                                <?php
                                                                    $grade1=4;
                                                                ?>
                                                                <?php echo e($grade1); ?>

                                                            <?php elseif($gpa>=80 && $gpa<90): ?>
                                                                    <?php
                                                                        $grade1=4;
                                                                    ?>
                                                                    <?php echo e($grade1); ?>

                                                            <?php elseif($gpa>=75 && $gpa<90): ?>
                                                                    <?php
                                                                        $grade1=3.7;
                                                                    ?>
                                                                    <?php echo e($grade1); ?>


                                                            <?php elseif($gpa>=70 && $gpa<75): ?>
                                                                    <?php
                                                                        $grade1=3.4;
                                                                    ?>
                                                                    <?php echo e($grade1); ?>

                                                            <?php elseif($gpa>=65 && $gpa<70): ?>
                                                                    <?php
                                                                        $grade1=3.1;
                                                                    ?>
                                                                    <?php echo e($grade1); ?>

                                                            <?php elseif($gpa>=60 && $gpa<65): ?>
                                                                    <?php
                                                                        $grade1=2.7;
                                                                    ?>
                                                                    <?php echo e($grade1); ?>

                                                            <?php elseif($gpa>=55 && $gpa<60): ?>
                                                                    <?php
                                                                        $grade1=2.4;
                                                                    ?>
                                                                    <?php echo e($grade1); ?>

                                                            <?php elseif($gpa>=50 && $gpa<55): ?>
                                                                    <?php
                                                                        $grade1=2.1;
                                                                    ?>
                                                                    <?php echo e($grade1); ?>

                                                            <?php elseif($gpa>=45 && $gpa<50): ?>
                                                                    <?php
                                                                        $grade1=1.7;
                                                                    ?>
                                                                    <?php echo e($grade1); ?>

                                                            <?php elseif($gpa>=40 && $gpa<45): ?>
                                                                    <?php
                                                                        $grade1=1.4;
                                                                    ?>
                                                                    <?php echo e($grade1); ?>

                                                            <?php elseif($gpa>=35 && $gpa<40): ?>
                                                                    <?php
                                                                        $grade1=1;
                                                                    ?>
                                                                    <?php echo e($grade1); ?>

                                                            <?php else: ?>
                                                                    <?php
                                                                        $grade1=0;
                                                                    ?>
                                                                    <?php echo e($grade1); ?>

                                                             <?php endif; ?>


                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <th>CGPA</th>
                                                            <td>0</td>
                                                        </tr>
                                                    </thead>
                                                    <tbody>








                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <div class="col-md-10">
                                            <div class="table-responsive">
                                                <table class="table table-bordered border-primary mb-0">

                                                    <thead>
                                                    <tr>
                                                        <th> Course Code</th>

                                                        <?php for($i=1;$i<=10;$i++): ?>
                                                            <th>PLO <?php echo e($i); ?></th>
                                                        <?php endfor; ?>
                                                    </tr>
                                                    </thead>
                                                    <tbody>

                                                    <tr>
                                                        <td>GPA</td>


                                                        <td>
                                                            <?php if($avg1!=0): ?>
                                                                <?php echo e($total1/10); ?>

                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php if($avg2!=0): ?>
                                                                <?php echo e($total2/10); ?>

                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php if($avg3!=0): ?>
                                                                <?php echo e($total3/10); ?>

                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php if($avg4!=0): ?>
                                                                <?php echo e($total4/10); ?>

                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php if($avg5!=0): ?>
                                                                <?php echo e($total5/10); ?>

                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php if($avg6!=0): ?>
                                                                <?php echo e($total6/10); ?>

                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php if($avg7!=0): ?>
                                                                <?php echo e($total7/10); ?>

                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php if($avg8!=0): ?>
                                                                <?php echo e($total8/10); ?>

                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php if($avg9!=0): ?>
                                                                <?php echo e($total9/10); ?>

                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php if($avg10!=0): ?>
                                                                <?php echo e($total10/10); ?>

                                                            <?php endif; ?>
                                                        </td>



                                                    </tr>





                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        




                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <canvas id="marksChart" width="600" height="400"></canvas>
                        </div>
                    </div>
                </div>
                <!-- end card body -->
            </div>
        </div>
        <!-- end row -->
    </div>
    <!-- container-fluid -->
</div>
<script>


    var marksCanvas = document.getElementById("marksChart");
    var marksCanvas2 = document.getElementById("marksChart2");
    var avg1 = "<?php echo $avg1; ?>";
    var avg2 = "<?php echo $avg2; ?>";
    var avg3 = "<?php echo $avg3; ?>";
    var avg4 = "<?php echo $avg4; ?>";
    var avg5 = "<?php echo $avg5; ?>";
    var avg6 = "<?php echo $avg6; ?>";
    var avg7 = "<?php echo $avg7; ?>";
    var avg7 = "<?php echo $avg7; ?>";
    var avg8 = "<?php echo $avg8; ?>";
    var avg9 = "<?php echo $avg9; ?>";
    var avg10 = "<?php echo $avg10; ?>";

    var total1 = "<?php echo $total1; ?>";
    var total2 = "<?php echo $total2; ?>";
    var total3 = "<?php echo $total3; ?>";
    var total4 = "<?php echo $total4; ?>";
    var total5 = "<?php echo $total5; ?>";
    var total6 = "<?php echo $total6; ?>";
    var total7 = "<?php echo $total7; ?>";
    var total7 = "<?php echo $total7; ?>";
    var total8 = "<?php echo $total8; ?>";
    var total9 = "<?php echo $total9; ?>";
    var total10 = "<?php echo $total10; ?>";

    var marksData = {
    labels: ["PLO1", "PLO2", "PLO3", "PLO4", "PLO5", "PLO6","PLO7","PLO8","PLO9","PLO10"],
    datasets: [{
        label: "GPA",
        backgroundColor: "rgba(200,0,0,0.2)",
        data: [avg1, avg2, avg3, avg4, avg5, avg6,avg7,avg8,avg9,avg10]
    }, {
        label: "CGPA",
        backgroundColor: "rgba(0,0,200,0.2)",
        data: [total1, total2, total3, total4, total5, total6,total7,total8,total9,total10]
    }]
    };

var radarChart = new Chart(marksCanvas, {
  type: 'radar',
  data: marksData
});
var radarChart2 = new Chart(marksCanvas2, {
  type: 'radar',
  data: marksData
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\fiverr\crud\resources\views/plo_generation/plo_table.blade.php ENDPATH**/ ?>