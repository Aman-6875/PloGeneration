<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="container-fluid">

        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0 font-size-18"><?php echo e(\App\Courses::find($course_code)->course_code); ?></h4>

                     <div class="page-title-right">
                        
                    </div>

                </div>
            </div>
        </div>
        <!-- end page title -->

        <div class="row">
            <div class="card">
                <div class="card-body">
                    <center>
                        <h4 class="card-title mb-4"><?php echo e(\App\Courses::find($course_code)->course_code); ?></h4>
                    </center>



                    <div class="row">
                        <div class="col-xl-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">

                                        <div class="col-md-12">
                                            <div class="table-responsive">
                                                <table class="table table-bordered border-primary mb-0">

                                                    <thead>
                                                    <tr>
                                                        <th> Student Name</th>

                                                        <?php for($i=1;$i<=10;$i++): ?>
                                                            <th>PLO <?php echo e($i); ?></th>
                                                        <?php endfor; ?>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                        
                                                    <?php
                                                         $student = App\User::where('user_role','Student')->get();
                                                        //  @dd($student);
                                                    ?>
                                                    <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        
                                                        <?php
                                                             $ploData2 =   App\MarksWithCloPlo::where('course_id',$course_code)->where('student_id',$item->user_id)->join('plos','marks_with_clo_plos.plo_id','=','plos.id')->select('marks_with_clo_plos.*','plos.name')->get();
                                                            // $ploData2 = App\MarksWithCloPlo::where('student_id',$item->user_id)->get();

                                                        ?>


                                                        <?php
                                                         $i=0;
        $j=0;
        $k=0;
        $l=0;
        $m=0;
        $n=0;
        $o=0;
        $p=0;
        $q=0;
        $r=0;
        $total1=0;
        $total2=0;
        $total3=0;
        $total4=0;
        $total5=0;
        $total6=0;
        $total7=0;
        $total8=0;
        $total9=0;
        $total10=0;
                                                            foreach($ploData2 as $data){

                                                                if($data->plo_id!=null){
                                                                    if($data->plo_id==1){
                                                                        $total1 = $total1 +$data->mark;
                                                                        $i++;
                                                                    }
                                                                    elseif($data->plo_id==2){
                                                                        $total2 = $total2 + $data->mark;
                                                                        $j++;
                                                                    }
                                                                    elseif($data->plo_id==3){
                                                                        $total3 = $total3 +$data->mark;
                                                                        $k++;
                                                                    }
                                                                    elseif($data->plo_id==4){
                                                                        $total4 = $total4 +$data->mark;
                                                                        $l++;
                                                                    }
                                                                    elseif($data->plo_id==5){
                                                                        $total5 = $total5 + $data->mark;
                                                                        $m++;
                                                                    }
                                                                    elseif($data->plo_id==6){
                                                                        $total6 = $total6 + $data->mark;
                                                                        $n++;
                                                                    }
                                                                    elseif($data->plo_id==7){
                                                                        $total7 = $total7 + $data->mark;
                                                                        $o++;
                                                                    }
                                                                    elseif($data->plo_id==8){
                                                                        $total8 = $total8 +$data->mark;
                                                                        $p++;
                                                                    }
                                                                    elseif($data->plo_id==9){
                                                                        $total9 = $total9 +$data->mark;
                                                                        $q++;
                                                                    }
                                                                    elseif($data->plo_id==10){
                                                                        $total10 = $total10 + $data->mark;
                                                                        $r++;
                                                                    }

                                                                }

                                                            }
                                                            // dd($total1);
                                                            // dd($total2);

                                                        ?>

                                                        <td><?php echo e($item->first_name); ?></td>
                                                        <td><?php echo e($total1/10); ?></td>
                                                        <td><?php echo e($total2/10); ?></td>
                                                        <td><?php echo e($total3/10); ?></td>
                                                        <td><?php echo e($total4/10); ?></td>
                                                        <td><?php echo e($total5/10); ?></td>
                                                        <td><?php echo e($total6/10); ?></td>
                                                        <td><?php echo e($total7/10); ?></td>
                                                        <td><?php echo e($total8/10); ?></td>
                                                        <td><?php echo e($total9/10); ?></td>
                                                        <td><?php echo e($total10/10); ?></td>




                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>






                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        




                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>
                <!-- end card body -->
            </div>
        </div>
        <!-- end row -->
    </div>
    <!-- container-fluid -->
</div>
<script>


</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\fiverr\crud\resources\views/plo_generation/plo_table_all_data.blade.php ENDPATH**/ ?>