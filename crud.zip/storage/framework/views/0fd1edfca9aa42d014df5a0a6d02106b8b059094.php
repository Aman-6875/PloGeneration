<div id="sidebar-menu">
    <!-- Left Menu Start -->
    <ul class="metismenu list-unstyled" id="side-menu">
        <li class="menu-title" key="t-menu">Menu</li>

        <li>
            <a href="/" class="waves-effect">
                <i class="bx bx-home-circle"></i><span class="badge rounded-pill bg-info float-end"></span>
                <span key="t-dashboards">Dashboards</span>
            </a>
        </li>
        <?php if(Auth::user()->user_role!='Student'): ?>
        <?php if(Auth::user()->user_type==1): ?>
        
        <?php endif; ?>


        <li class="menu-title" key="t-apps">Actions</li>
        <li>
            <a href="/create-plo-generation" class="waves-effect">
                <i class="bx bx-file"></i>
                <span key="t-utility">PLO GENERATION</span>
            </a>
            <a href="/plo-table-search" class="waves-effect">
                <i class="bx bx-file"></i>
                <span key="t-utility">PLO Table</span>
            </a>
            <a href="<?php echo e(route('course.create')); ?>" class="waves-effect">
                <i class="bx bx-file"></i>
                <span key="t-utility">Create Course</span>
            </a>
        </li>
        <?php else: ?>
        <li class="menu-title" key="t-apps">Actions</li>
        <li>
            <a href="/plo-table-search" class="waves-effect">
                <i class="bx bx-file"></i>
                <span key="t-utility">PLO Table</span>
            </a>
            <a href="<?php echo e(route('enroll.course')); ?>" class="waves-effect">
                <i class="bx bx-file"></i>
                <span key="t-utility">Enroll Course</span>
            </a>
        </li>
        <?php endif; ?>

    </ul>
</div>
<?php /**PATH E:\fiverr\crud\resources\views/admin/includes/sidebar.blade.php ENDPATH**/ ?>