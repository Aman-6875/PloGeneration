<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="mb-sm-0 font-size-18">Dashboard</h4>

                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="/">Dashboards</a></li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <!-- end page title -->
            
            <?php if(Auth::user()->user_role=='Student'): ?>
            <div class="row">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title mb-4">PLO GENERATION</h4>

                        <form action="/get-plo-generation-table" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo $__env->make('admin.includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="row mb-4">
                                        <label for="horizontal-email-input" class="col-sm-3 col-form-label">Choose Course Code</label>
                                        <div class="col-sm-6">
                                            <select

                                                class="form-select course-code"
                                                name="course_code">
                                                <option value="">SELECT</option>
                                                <?php
                                                    $courses = App\Courses::all();
                                                ?>
                                                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($course->id); ?>"><?php echo e($course->course_code); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>






                            <div class="row justify-content-end">
                                <div class="col-sm-8">
                                    <div>
                                        <button type="submit" class="btn btn-primary w-md">Report</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <!-- end card body -->
                </div>

            </div>
            <?php endif; ?>

            <!-- end row -->
            <br><br>
            <div class="row">

            </div>

        </div>
        <!-- container-fluid -->
    </div>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\fiverr\crud\resources\views/home.blade.php ENDPATH**/ ?>