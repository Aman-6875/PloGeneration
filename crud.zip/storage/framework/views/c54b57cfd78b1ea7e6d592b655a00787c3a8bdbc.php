

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container-fluid">
            <?php
            $developer=0;
            $designer=0;
            $ceo=0;
            $cto=0;
            $entrepreneur=0;
            $startup=0;
            $undefined=0;
            $marketer=0;
            $seo=0;
            $data_scientist=0;
            $Linux=0;
            $Mac=0;
            $Windows=0;
            $Facebook=0;
            $Google=0;
            $LinkedIn=0;
            $Twitter=0;
            $Instagram=0;
            $Github=0;
        ?>

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="mb-sm-0 font-size-18">Dashboard</h4>

                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="/">Dashboards</a></li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-xl-4">
                    <div class="card overflow-hidden">
                        <div class="bg-primary bg-soft">
                            <div class="row">
                                <div class="col-7">
                                    <div class="text-primary p-3">
                                        <h5 class="text-primary">Welcome Back !</h5>
                                        <h5 class="font-size-15 text-truncate"><?php echo e(Auth::user()->name); ?></h5>

                                    </div>
                                </div>
                                <div class="col-5 align-self-end">
                                    <img src="/assets/images/profile-img.png" alt="" class="img-fluid">
                                </div>
                            </div>
                        </div>
                        <div class="card-body pt-0">
                            <div class="row">

                            </div>
                        </div>
                    </div>

                </div>
                <div class="col-xl-8">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="card mini-stats-wid">
                                <div class="card-body">
                                    <div class="media">
                                        <div class="media-body">
                                            <p class="text-muted fw-medium">Total Customers</p>
                                            <h4 class="mb-0"><?php echo e($customer); ?></h4>
                                        </div>

                                        <div class="mini-stat-icon avatar-sm rounded-circle bg-primary align-self-center">
                                            <span class="avatar-title">
                                                <i class="bx bx-copy-alt font-size-24"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php if(Auth::user()->user_type == 1): ?>
                            <div class="col-md-4">
                                <div class="card mini-stats-wid">
                                    <div class="card-body">
                                        <div class="media">
                                            <div class="media-body">
                                                <p class="text-muted fw-medium">Active Users</p>
                                                <h4 class="mb-0"><?php echo e($active); ?></h4>
                                            </div>

                                            <div
                                                class="avatar-sm rounded-circle bg-primary align-self-center mini-stat-icon">
                                                <span class="avatar-title rounded-circle bg-primary">
                                                    <i class="bx bx-archive-in font-size-24"></i>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card mini-stats-wid">
                                    <div class="card-body">
                                        <div class="media">
                                            <div class="media-body">
                                                <p class="text-muted fw-medium">Pending Users</p>
                                                <h4 class="mb-0"><?php echo e($pending); ?></h4>
                                            </div>

                                            <div
                                                class="avatar-sm rounded-circle bg-primary align-self-center mini-stat-icon">
                                                <span class="avatar-title rounded-circle bg-primary">
                                                    <i class="bx bx-archive-in font-size-24"></i>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <?php $__currentLoopData = $Allcustomer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item->profession == 'Developer'): ?>
                                    <?php
                                        $developer++;
                                    ?>
                                <?php elseif($item->profession == 'Designer'): ?>
                                    <?php
                                        $designer++
                                    ?>
                                <?php elseif($item->profession == 'Ceo'): ?>
                                    <?php
                                        $ceo++
                                    ?>
                                <?php elseif($item->profession == 'Cto'): ?>
                                    <?php
                                        $cto++
                                    ?>
                                <?php elseif($item->profession == 'Entrepreneur'): ?>
                                    <?php
                                        $entrepreneur++
                                    ?>
                                <?php elseif($item->profession == 'Startup owner'): ?>
                                    <?php
                                        $startup++
                                    ?>
                                <?php elseif($item->profession == 'Undefined'): ?>
                                    <?php
                                        $undefined++
                                    ?>
                                <?php elseif($item->profession == 'Marketer'): ?>
                                    <?php
                                        $marketer++
                                    ?>
                                <?php elseif($item->profession == 'Seo specilist'): ?>
                                    <?php
                                        $seo++
                                    ?>
                                <?php elseif($item->profession == 'Data scientist'): ?>
                                    <?php
                                        $data_scientist++
                                    ?>
                                <?php endif; ?>
                                <?php if($item->device == 'Linux'): ?>
                                    <?php
                                        $Linux++;
                                    ?>
                                <?php elseif($item->device == 'Mac'): ?>
                                    <?php
                                        $Mac++
                                    ?>
                                <?php elseif($item->device == 'Windows'): ?>
                                    <?php
                                        $Windows++
                                    ?>
                                <?php endif; ?>
                                <?php if($item->facebook_link != null): ?>
                                    <?php
                                        $Facebook++;
                                    ?>
                                    <?php endif; ?>
                                <?php if($item->google_link != null): ?>
                                    <?php
                                        $Google++
                                    ?>
                                    <?php endif; ?>
                                <?php if($item->linked_in_link != null): ?>
                                    <?php
                                        $LinkedIn++
                                    ?>
                                    <?php endif; ?>
                                <?php if($item->twitter_link != null): ?>
                                    <?php
                                        $Twitter++
                                    ?>
                                    <?php endif; ?>

                                <?php if($item->instagram_link != null): ?>
                                    <?php
                                        $Instagram++
                                    ?>
                                    <?php endif; ?>
                                <?php if($item->github_link != null): ?>
                                    <?php
                                        $Github++
                                    ?>
                                <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6">
                                <div class="card mini-stats-wid">
                                    <div class="card-body">
                                        <div class="media">
                                            <div class="media-body">
                                                <p class="text-muted fw-medium">Customer Data Based on Profession</p>

                                                <h4 class="mb-0">Developer:<?php echo e($developer); ?></h4>
                                                <h4 class="mb-0">Designer:<?php echo e($designer); ?></h4>
                                                <h4 class="mb-0">Ceo:<?php echo e($ceo); ?></h4>
                                                <h4 class="mb-0">Cto:<?php echo e($cto); ?></h4>
                                                <h4 class="mb-0">Entrepreneur:<?php echo e($entrepreneur); ?></h4>
                                                <h4 class="mb-0">Startup owner:<?php echo e($startup); ?></h4>
                                                <h4 class="mb-0">Undefined:<?php echo e($undefined); ?></h4>
                                                <h4 class="mb-0">Marketer:<?php echo e($marketer); ?></h4>
                                                <h4 class="mb-0">Seo specilist:<?php echo e($seo); ?></h4>
                                                <h4 class="mb-0">Data scientist:<?php echo e($data_scientist); ?></h4>

                                            </div>

                                            <div
                                                class="avatar-sm rounded-circle bg-primary align-self-center mini-stat-icon">
                                                <span class="avatar-title rounded-circle bg-primary">
                                                    <i class="bx bx-archive-in font-size-24"></i>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card mini-stats-wid">
                                    <div class="card-body">
                                        <div class="media">
                                            <div class="media-body">
                                                <p class="text-muted fw-medium">Customer Data Based on Device</p>

                                                <h4 class="mb-0">Linux:<?php echo e($Linux); ?></h4>
                                                <h4 class="mb-0">Mac:<?php echo e($Mac); ?></h4>
                                                <h4 class="mb-0">Windows:<?php echo e($Windows); ?></h4>
                                            </div>

                                            <div
                                                class="avatar-sm rounded-circle bg-primary align-self-center mini-stat-icon">
                                                <span class="avatar-title rounded-circle bg-primary">
                                                    <i class="bx bx-archive-in font-size-24"></i>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="media">
                                            <div class="media-body">
                                                <p class="text-muted fw-medium">Customer Data Based on Social Link</p>
                                                <h4 class="mb-0">Facebook-User:<?php echo e($Facebook); ?></h4>
                                                <h4 class="mb-0">Google-User:<?php echo e($Google); ?></h4>
                                                <h4 class="mb-0">LinkedIn-User:<?php echo e($LinkedIn); ?></h4>
                                                <h4 class="mb-0">Twitter-User:<?php echo e($Twitter); ?></h4>
                                                <h4 class="mb-0">Instagram-User:<?php echo e($Instagram); ?></h4>
                                                <h4 class="mb-0">Github-User:<?php echo e($Github); ?></h4>
                                            </div>

                                            <div
                                                class="avatar-sm rounded-circle bg-primary align-self-center mini-stat-icon">
                                                <span class="avatar-title rounded-circle bg-primary">
                                                    <i class="bx bx-archive-in font-size-24"></i>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>





                    </div>
                    <!-- end row -->
                </div>
            </div>
            <!-- end row -->
            <br><br>
            <div class="row">
                <div class="col-md-6">
                    <div id="pie_chart" style="width:550px; height:450px;"></div>
                </div>
                <div class="col-md-6">
                    <div id="pie_chart_country" style="width:550px; height:450px;"></div>
                </div>
                <div class="col-md-6">
                    <div id="pie_chart_profession" style="width:550px; height:450px;"></div>
                </div>
                <div class="col-md-6">
                    <div id="pie_chart_device" style="width:550px; height:450px;"></div>
                </div>
                <div class="col-md-6">
                    <div id="pie_chart_social" style="width:550px; height:450px;"></div>
                </div>
                <div class="col-md-6">
                    <div id="pie_chart_price" style="width:550px; height:450px;"></div>
                </div>
                
            </div>
            <?php endif; ?>
        </div>
        <!-- container-fluid -->
    </div>




    <script>
        var analytics = <?php echo $gender; ?>;
        var country = <?php echo $country; ?>;
        var profession = <?php echo $profession; ?>;
        var device = <?php echo $device; ?>;
        var price = <?php echo $price; ?>;
        var Facebook = <?php echo $Facebook; ?>;
        var Google = <?php echo $Google; ?>;
        var LinkedIn = <?php echo $LinkedIn; ?>;
        var Twitter = <?php echo $Twitter; ?>;
        var Instagram = <?php echo $Instagram; ?>;
        var Github = <?php echo $Github; ?>;



        google.charts.load('current', {'packages':['corechart']});

        google.charts.setOnLoadCallback(drawChart);
        google.charts.setOnLoadCallback(drawCountryChart);
        google.charts.setOnLoadCallback(drawProfessionChart);
        google.charts.setOnLoadCallback(drawDeviceChart);
        google.charts.setOnLoadCallback(drawSocialChart);
        google.charts.setOnLoadCallback(drawPriceChart);

        function drawChart()
        {
            var data = google.visualization.arrayToDataTable(analytics);
            var options = {
            title : 'Percentage of Male and Female Customer'
            };
            var chart = new google.visualization.PieChart(document.getElementById('pie_chart'));
            chart.draw(data, options);
        }
        function drawCountryChart()
        {
            var country_data = google.visualization.arrayToDataTable(country);
            var options = {
            title : 'Country Based Customer'
            };
            var chart = new google.visualization.PieChart(document.getElementById('pie_chart_country'));
            chart.draw(country_data, options);
        }
        function drawProfessionChart()
        {
            var profession_data = google.visualization.arrayToDataTable(profession);
            var options = {
            title : 'Profession Based Customer'
            };
            var chart = new google.visualization.PieChart(document.getElementById('pie_chart_profession'));
            chart.draw(profession_data, options);
        }
        function drawDeviceChart()
        {
            var device_data = google.visualization.arrayToDataTable(device);
            var options = {
            title : 'Device Based Customer'
            };
            var chart = new google.visualization.PieChart(document.getElementById('pie_chart_device'));
            chart.draw(device_data, options);
        }
        function drawPriceChart()
        {
            var price_data = google.visualization.arrayToDataTable(price);
            var options = {
            title : 'Price Based Customer'
            };
            var chart = new google.visualization.PieChart(document.getElementById('pie_chart_price'));
            chart.draw(price_data, options);
        }
        function drawSocialChart()
        {
            var social_data = google.visualization.arrayToDataTable([
            ['Task', 'Hours per Day'],
            ['Facebook',     Facebook],
            ['Google',     Google],
            ['LinkedIn',     LinkedIn],
            ['Twitter',     Twitter],
            ['Instagram',     Instagram],
            ['Github',     Github],

             ]);
            var options = {
            title : 'Social Based Customer'
            };
            var chart = new google.visualization.PieChart(document.getElementById('pie_chart_social'));
            chart.draw(social_data, options);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\home_practice\crud\resources\views/home.blade.php ENDPATH**/ ?>