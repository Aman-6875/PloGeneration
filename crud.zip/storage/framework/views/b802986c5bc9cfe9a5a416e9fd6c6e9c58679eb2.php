<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="container-fluid">

        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0 font-size-18">Input Marks Based On CLO</h4>



                </div>
            </div>
        </div>


        <div class="row">
            <div class="card">
                <div class="card-body">
                    <center>
                        
                    </center>
                    <form action="/save-clo-generation" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo $__env->make('admin.includes.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="row">
                            <div class="col-xl-12">
                                <div class="card">
                                    <div class="card-body">

                                        <div class="table-responsive">
                                            <table class="table table-bordered border-primary mb-0">

                                                <thead>

                                                    <tr>
                                                        <th>Student Name</th>
                                                        <?php $__currentLoopData = $datas[0]['marking_parameter']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marking_parameter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                           <?php if($marking_parameter!=null): ?>
                                                             <?php

                                                                $parameter_name =  App\MarkingParameter::where('id',$marking_parameter)->first();
                                                             ?>
                                                            <?php if($parameter_name->id == 10): ?>
                                                            <?php for($k=1;$k<=6;$k++): ?>{
                                                                <th><?php echo e($parameter_name->name); ?>.Q-<?php echo e($k); ?></th>
                                                            }
                                                            <?php endfor; ?>

                                                            <?php else: ?>
                                                            <th><?php echo e($parameter_name->name); ?></th>
                                                            <?php endif; ?>



                                                           <?php endif; ?>


                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <th>Total%</th>
                                                    </tr>
                                                </thead>

                                                <tbody>
                                                <?php
                                                    $students = App\User::where('user_role','Student')->get();
                                                    $i = 0;
                                                ?>

                                                 <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                 <tr>

                                                    <td><?php echo e($student->first_name); ?></td>
                                                    <?php $__currentLoopData = $datas[0]['marking_parameter']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marking_parameter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($marking_parameter!= null): ?>
                                                    <?php if($marking_parameter == 10): ?>
                                                    <?php for($j=0; $j<6; $j++): ?>
                                                             <td>
                                                                 <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clo_index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                     <input

                                                                         id="clo-<?php echo e($student->id); ?>-<?php echo e($data['clo_id']); ?>"
                                                                         class="form-control"
                                                                         type="number"
                                                                         name="marks[]"
                                                                         placeholder="<?php echo e("CLO-".$data['clo_id']); ?>"
                                                                         onchange="adjustTotal(<?php echo e($student->id); ?>,<?php echo e($data['clo_id']); ?>,<?php echo e($marking_parameter); ?>,<?php echo e(json_encode($data)); ?>)"
                                                                     <?php
                                                                         $marking_parameter_index = array_search($marking_parameter,$data['marking_parameter']);
                                                                         $given_mark = $data['input_number'][$marking_parameter_index];
                                                                         if (!$given_mark) echo 'readonly';
                                                                         ?>
                                                                     ><br>
                                                                     <input class="form-control" type="hidden"name="clo_id[]" value="<?php echo e($data['clo_id']); ?>">
                                                                     <input class="form-control" type="hidden"name="plo_id[]" value="<?php echo e($data['plo_id']); ?>">
                                                                     <input class="form-control" type="hidden"name="course_id" value="<?php echo e($data['course_id']); ?>">
                                                                     <input class="form-control" type="hidden"name="marking_parameter[]" value="<?php echo e($marking_parameter); ?>">
                                                                     <input class="form-control" type="hidden"name="student_id[]" value="<?php echo e($student->user_id); ?>">
                                                                     <?php
                                                                         $i++;
                                                                     ?>
                                                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                             </td>
                                                     <?php endfor; ?>
                                                 <?php else: ?>
                                                         <td>
                                                             <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clo_index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                 <input
                                                                        style="width: 70px"
                                                                     id="clo-<?php echo e($student->id); ?>-<?php echo e($data['clo_id']); ?>"
                                                                     class="form-control"
                                                                     type="number"
                                                                     name="marks[]"
                                                                     placeholder="<?php echo e("CLO-".$data['clo_id']); ?>"
                                                                     onchange="adjustTotal(<?php echo e($student->id); ?>,<?php echo e($data['clo_id']); ?>,<?php echo e($marking_parameter); ?>,<?php echo e(json_encode($data)); ?>)"
                                                                 <?php
                                                                     $marking_parameter_index = array_search($marking_parameter,$data['marking_parameter']);
                                                                     $given_mark = $data['input_number'][$marking_parameter_index];
                                                                     if (!$given_mark) echo 'readonly';
                                                                     ?>
                                                                 ><br>
                                                                 <input class="form-control" type="hidden"name="clo_id[]" value="<?php echo e($data['clo_id']); ?>">
                                                                 <input class="form-control" type="hidden"name="plo_id[]" value="<?php echo e($data['plo_id']); ?>">
                                                                 <input class="form-control" type="hidden"name="course_id" value="<?php echo e($data['course_id']); ?>">
                                                                 <input class="form-control" type="hidden"name="marking_parameter[]" value="<?php echo e($marking_parameter); ?>">
                                                                 <input class="form-control" type="hidden"name="student_id[]" value="<?php echo e($student->user_id); ?>">
                                                                 <?php
                                                                     $i++;
                                                                 ?>
                                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                         </td>
                                                <?php endif; ?>

                                                    <?php endif; ?>
                                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <td>
                                        <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <input
                                        class="form-control"
                                        id="total-<?php echo e($student->id); ?>-<?php echo e($d['clo_id']); ?>"
                                        type="number" readonly><br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                                        </tbody>
                                        </table>
                                        </div>

                                        </div>
                                        </div>
                                        </div>
                                        </div>

                                        <div class="row justify-content-center">
                                        <div class="col-sm-9">
                                        <center>
                                        <button type="submit" class="btn btn-primary w-50">Save</button>
                                        </center>
                                        </div>
                                        </div>
                                        </form>
                                        </div>
                                        <!-- end card body -->
                                        </div>
                                        </div>
                                        <!-- end row -->
                                        </div>
                                        <!-- container-fluid -->
                                        </div>

                            <script>
                            function adjustTotal(student_id,id,marking_parameter,data){
                            let element_value = document.getElementById('clo-'+student_id+'-'+id)
                            let element_total = document.getElementById('total-'+student_id+'-'+id)
                                let is_okay = cloValidation(marking_parameter,data,parseFloat(element_value.value))
                                if (!is_okay) element_value.value = ''
                            let total_value = parseFloat(element_total.value)
                            if (isNaN(total_value)) total_value = 0
                            total_value+= parseFloat(element_value.value)
                            element_total.value = total_value
                            }

                            function cloValidation(marking_parameter,data,value)
                            {
                                let marking_parameters = data.marking_parameter
                                let input_numbers = data.input_number
                                let marking_param_index = marking_parameters.indexOf(String(marking_parameter))
                                if (value > input_numbers[marking_param_index]){
                                    alert('Value can not be greater than '+ input_numbers[marking_param_index]);
                                    return false
                                }
                                return true

                            }
                            </script>
                            <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\fiverr\crud\resources\views/clo_generation/create.blade.php ENDPATH**/ ?>