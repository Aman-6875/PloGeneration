<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StudentObtain extends Model
{
    public $timestamps=true;
    public $guarded=[];
}
