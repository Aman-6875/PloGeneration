<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MarkingDistribution extends Model
{
    protected $guarded = ['id'];
}
