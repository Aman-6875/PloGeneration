<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CloPloEngagement extends Model
{
    protected $guarded = ['id'];
}
