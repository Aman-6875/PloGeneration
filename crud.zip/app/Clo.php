<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Clo extends Model
{
    public $timestamps=true;
    public $guarded=[];
}
