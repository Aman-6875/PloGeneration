<?php

namespace App\Http\Controllers;

use App\MarksWithCloPlo;
use Illuminate\Http\Request;

class MarksWithCloPloController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\MarksWithCloPlo  $marksWithCloPlo
     * @return \Illuminate\Http\Response
     */
    public function show(MarksWithCloPlo $marksWithCloPlo)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\MarksWithCloPlo  $marksWithCloPlo
     * @return \Illuminate\Http\Response
     */
    public function edit(MarksWithCloPlo $marksWithCloPlo)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\MarksWithCloPlo  $marksWithCloPlo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MarksWithCloPlo $marksWithCloPlo)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\MarksWithCloPlo  $marksWithCloPlo
     * @return \Illuminate\Http\Response
     */
    public function destroy(MarksWithCloPlo $marksWithCloPlo)
    {
        //
    }
}
