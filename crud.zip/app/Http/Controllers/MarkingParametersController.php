<?php

namespace App\Http\Controllers;

use App\marking_parameters;
use Illuminate\Http\Request;

class MarkingParametersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\marking_parameters  $marking_parameters
     * @return \Illuminate\Http\Response
     */
    public function show(marking_parameters $marking_parameters)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\marking_parameters  $marking_parameters
     * @return \Illuminate\Http\Response
     */
    public function edit(marking_parameters $marking_parameters)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\marking_parameters  $marking_parameters
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, marking_parameters $marking_parameters)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\marking_parameters  $marking_parameters
     * @return \Illuminate\Http\Response
     */
    public function destroy(marking_parameters $marking_parameters)
    {
        //
    }
}
