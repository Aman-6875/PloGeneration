<?php

namespace App\Http\Controllers;

use App\MarkingDistribution;
use Illuminate\Http\Request;

class MarkingDistributionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\MarkingDistribution  $markingDistribution
     * @return \Illuminate\Http\Response
     */
    public function show(MarkingDistribution $markingDistribution)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\MarkingDistribution  $markingDistribution
     * @return \Illuminate\Http\Response
     */
    public function edit(MarkingDistribution $markingDistribution)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\MarkingDistribution  $markingDistribution
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, MarkingDistribution $markingDistribution)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\MarkingDistribution  $markingDistribution
     * @return \Illuminate\Http\Response
     */
    public function destroy(MarkingDistribution $markingDistribution)
    {
        //
    }
}
