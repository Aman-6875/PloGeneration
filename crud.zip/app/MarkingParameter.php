<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MarkingParameter extends Model
{
    public $timestamps=true;
    public $guarded=[];
}
